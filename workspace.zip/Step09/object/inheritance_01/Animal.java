package inheritance_01;

public class Animal {
//	private int age; // 필드선언
	protected int age; // 필드선언
	
	public Animal() {// 기본 생성자 
		age = 20;
		System.out.println("Animal 생성자");
	}
	
	public void eat() {
		System.out.println("동물이 먹이를 먹습니다.");
	}
	
	
	
}
