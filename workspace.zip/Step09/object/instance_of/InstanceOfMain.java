package instance_of;

public class InstanceOfMain {
	
	public static void main(String[] args) {
		
		Person p = new Person();
		Animal a = p; // 자동 형변환, 작은개념이 큰개념이 되는 경우
//		Person p = a;
		Person p1 = (Person)a;
		
		p.eat();
		a.eat();
		
		// 다 같은 주소값
		System.out.println(p);
		System.out.println(p1);
		System.out.println(a);
		
//		Dog d = (Dog) a; // cannot be cast to class instance_of.Dog
//		d.eat();
System.out.println("=======================");
		//형변환이 가능한지 검사
		// A instanceof B --> 객체 A가 B클래스 타입으로 형변환이 되는가?
		System.out.println(p instanceof Person);
		System.out.println(p instanceof Animal);
//		System.out.println(p instanceof Dog);
		System.out.println(a instanceof Dog); // 에러가 나지는 않지만 false로 체크
		System.out.println(a instanceof Person);
		
		//클래스 이름 뽑아서 처리
		System.out.println(p.getClass().getSimpleName());
		System.out.println(p.getClass().getName());
		
		System.out.println(a.getClass().getSimpleName());
		System.out.println(a.getClass().getName());
		
		System.out.println(Person.class.getName());
		
//		패키지명은 java로 시작하지말것              
	}
}
