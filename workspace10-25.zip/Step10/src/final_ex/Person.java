
package final_ex;

public class Person extends Animal {

	public Person(int age) {
		super(age);
	}
//	final 키워드가 붙은 메서드는 오버라이딩을 금지 시킨다.
//	public void eat() {
//		
//	}

}
