package inter_ex;

public interface InterB extends InterA {
	public void interB();

}
