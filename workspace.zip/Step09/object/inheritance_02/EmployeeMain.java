package inheritance_02;

public class EmployeeMain {
	
	public static void work (Employee e) {
		e.work();
	}
	public static void main(String[] args) {
		
		Employee e1 = new Employee(); 
		SalaryEmployee e2 = new SalaryEmployee();
		DispatchEmployee e3 = new DispatchEmployee();
		
//		e1.work();
//		e2.work();
//		e3.work();
		
		work(e1);
		work(e2);
		work(e3);
		
		
	}
}
