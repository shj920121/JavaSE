package phone_test;

public class PhoneVO {
//		아래 데이터 형식을 저장할 제품 정보하나를 저장할 클래스를 작성하시오.
//		클래스 작성시 필드를 전부 초기화하는 생성자, setter/getter, toString, 제품정보를 출력하는 메서드를 작성해야 합니다.
//		저장할 데이터는 제품명, 제조사, 금액, 원산지 되겠습니다.
//
//		출력 형태
//
//		갤럭시S23 삼성 1200000 한국
			private String model;
			private String brand;
			private int price;
			private String madein;
			
			public PhoneVO(String model, String brand, int price, String madein) {
				this.model = model;
				this.brand = brand;
				this.price = price;
				this.madein = madein;
			}

			public String getModel() {
				return model;
			}

			public void setModel(String model) {
				this.model = model;
			}

			public String getBrand() {
				return brand;
			}

			public void setBrand(String brand) {
				this.brand = brand;
			}

			public int getPrice() {
				return price;
			}

			public void setPrice(int price) {
				this.price = price;
			}

			public String getMadein() {
				return madein;
			}

			public void setMadein(String madein) {
				this.madein = madein;
			}

			@Override
			public String toString() {
				return String.format("%10s %10s %d %10s, model, brand, price, madein");
			}
				public void pirntInfo() {
					System.out.println("%10s %10s %d %10s, model, brand, price, madein");
				}
		
}
