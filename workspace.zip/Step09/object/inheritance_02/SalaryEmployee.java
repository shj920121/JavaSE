package inheritance_02;

public class SalaryEmployee extends Employee {

	@Override
	public void work() {
		// TODO Auto-generated method stub
		System.out.println("직원이 영업을 합니다");
	}
	

	
}
