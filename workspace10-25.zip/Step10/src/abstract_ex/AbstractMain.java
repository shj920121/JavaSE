package abstract_ex;

public class AbstractMain {
	public static void main(String[] args) {
		
//		추상 클래스는 직접적으로 생성 불가
//		Animal animal = new Animal();
		Person person = new Person();
		person.run();
		person.eat();
		
//		간접적인 생성은 가능
//		추상 클래스도 데이터 타입. 자식클래스를 형변환 시켜서 저장
		Animal animal = person;
		animal.eat();
		
		Dog dog = new Dog();
		dog.run();
		dog.eat();
		
	}
}
