package inter_ex;

public class InterClass implements InterA {

	@Override
	public void interA() {
		System.out.println("interA");
	}

}
