package abstract_ex;

public class Dog extends Animal {

	@Override
	public void run() {
		System.out.println("개가 달립니다.");
	}

}
