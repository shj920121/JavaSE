package inheritance_01;

public class PersonMain {
	
	public static void main(String[] args) {
		Person p = new Person();
		p.eat(); // eat() : void(리턴타입) - Animal(상속해준곳)
		p.run();
		p.printAge();
		
	}
	
	
}
