package abstract_ex;

public class Person extends Animal {

	
//	추상 메서드는 반드시 오버라이딩 해줘야 됌
//	오버라이딩을 안할 경우에는 해당 클래스도ㅓ 추상 클래스로 작성
	
	public Person() {
		System.out.println("Person Constructor");
	}
	
	
	@Override
	public void run() {
		System.out.println("사람이 달립니다.");
	}

	
	
	
	
}
