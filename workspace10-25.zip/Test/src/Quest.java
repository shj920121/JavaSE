//class Quest {
//   public int stringCount(String text, String search) {
//       int answer = 0;
//
//       //작업시작부분
//
//
//       return answer;
//   }
//}
//문자열 text와 search가 주어집니다. text에서 search에 저장된 문자열이 등장하는 횟수를 return 하는 메서드 부분을 완성해서 제출하세요.


public class Quest {
	public int stringCount(String text, String search) {
		int answer = 0;
		//작업시작부분
		
		
		int idx = 0;
		while(true) {
			idx = text.indexOf(search,idx);
			if(idx == -1) break;
			answer++;
			idx++;
		}
		return answer;
	}
//		while ((idx = text.indexOf(search, idx)) != -1) {
//			answer++;
//			idx++;
//		}
//				
//		return answer;
//	}
		
		
		public static void main(String[] args) {
			Quest3 quest3 = new Quest3();
			System.out.println(quest3.stringCount("Hello World Test", "1"));
				
	}
}
