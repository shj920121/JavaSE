package controller;

import java.util.Scanner;

public class Controller {
	public void execute(Scanner sc) {
		//1. 데이터 입력
		//2. Service 클래스로 처리할 데이터를 보내고, 결과를 받음
		//3. 결과 출력
	}
}