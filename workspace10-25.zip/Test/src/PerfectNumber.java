//	숫자 하나를 입력 받아서 해당 숫자가 완전수 인지 체크하는 프로그램을 작성하세요.
//
//	※ 완전수란 숫자의 약수들 중 자기 자신을 제외한 약수들의 합이 자기 자신과 동일한 숫자 입니다. 
//
//   6의 약수 : 1 2 3   --> 약수들의 합이 자기 자신과 같음, 완전수임

import java.util.Scanner;

public class PerfectNumber {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("숫자 입력 > ");
		int n = sc.nextInt();
		int sum = 0;
		for(int i=1; i<n; i++) {
			if(n % i == 0) { 
				sum += i;
			}
		}
		if(n == sum) {
		System.out.println("입력하신 숫자는 완전수입니다.");
		} else { 
			System.out.println("입력하신 숫자는 완전수가 아닙니다.");
		}
	}
}
