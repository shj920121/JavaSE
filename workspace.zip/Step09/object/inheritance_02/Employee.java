package inheritance_02;

public class Employee {
	public void work() {
		System.out.println("직원이 일을 합니다.");
	}
}
