package instance_of;

public class Dog extends Animal {

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		super.eat();
	}

	public void run() {
		System.out.println("개가 달립니다.");
	}
}
