package instance_of;

public class Person extends Animal {

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		super.eat();
	}
	
	public void work() {
		System.out.println("사람이 일을 합니다.");
	}
}
