package inter_ex;

public class InterBClass implements InterB {

	@Override
	public void interA() {
	
	}

	@Override
	public void interB() {
		
	}


}
