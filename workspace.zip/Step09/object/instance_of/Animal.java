package instance_of;

public class Animal {
	public void eat() {
		System.out.println("동물이 먹이를 먹습니다.");
	}
}
