package _super;

public class PersonMain {
	public static void main(String[] args) {
		
		Person p = new Person(20,"홍길동"); {
			p.printAge();
		}
	}
}
